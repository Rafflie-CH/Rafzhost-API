// api/downloader/youtube.js
export default async function handler(req, res) {
  const { link } = req.query;
  if (!link) return res.status(400).json({ error: 'Missing link parameter' });
  // TODO: replace with real YouTube logic
  const result = { success: true, platform: "youtube", link };
  return res.status(200).json(result);
}
