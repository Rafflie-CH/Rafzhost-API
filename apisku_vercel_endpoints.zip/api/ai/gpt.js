// api/ai/gpt.js
export default async function handler(req, res) {
  const { q } = req.query;
  if (!q) return res.status(400).json({ error: 'Missing q parameter' });
  // TODO: replace with real AI call
  const reply = "Pretend GPT reply to: " + q;
  return res.status(200).json({ answer: reply });
}
